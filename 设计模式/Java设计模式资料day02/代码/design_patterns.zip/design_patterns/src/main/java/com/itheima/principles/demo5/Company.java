package com.itheima.principles.demo5;

/**
 * @version v1.0
 * @ClassName: Company
 * @Description: 媒体公司类
 * @Author: 黑马程序员
 */
public class Company {
    private String name;

    public String getName() {
        return name;
    }

    public Company(String name) {
        this.name = name;
    }
}
