package com.itheima.dao;

/**
 * @version v1.0
 * @ClassName: UserDao
 * @Description: 数据访问层接口
 * @Author: 黑马程序员
 */
public interface UserDao {

    public void add();
}
