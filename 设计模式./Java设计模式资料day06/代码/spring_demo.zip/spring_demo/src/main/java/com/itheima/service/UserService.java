package com.itheima.service;

/**
 * @version v1.0
 * @ClassName: UserService
 * @Description: 业务逻辑层接口
 * @Author: 黑马程序员
 */
public interface UserService {

    public void add();
}
