package com.itheima.principles.demo1;

/**
 * @version v1.0
 * @ClassName: HeimaSkin
 * @Description: 黑马程序员皮肤
 * @Author: 黑马程序员
 */
public class HeimaSkin extends AbstractSkin {

    public void display() {
        System.out.println("黑马皮肤");
    }
}
