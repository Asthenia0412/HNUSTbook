package com.itheima.principles.demo3.after;

/**
 * @version v1.0
 * @ClassName: Memory
 * @Description: 内存条接口
 * @Author: 黑马程序员
 */
public interface Memory {

    public void save();
}


