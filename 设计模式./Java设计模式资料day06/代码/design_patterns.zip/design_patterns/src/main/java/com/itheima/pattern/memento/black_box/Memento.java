package com.itheima.pattern.memento.black_box;

/**
 * @version v1.0
 * @ClassName: Memento
 * @Description:  备忘录接口，对外提供窄接口
 * @Author: 黑马程序员
 */
public interface Memento {
}
