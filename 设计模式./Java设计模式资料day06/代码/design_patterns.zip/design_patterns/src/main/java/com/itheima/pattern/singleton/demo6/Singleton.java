package com.itheima.pattern.singleton.demo6;

/**
 * @version v1.0
 * @ClassName: Singleton
 * @Description: 枚举实现方式
 * @Author: 黑马程序员
 */
public enum Singleton {
    INSTANCE;
}
