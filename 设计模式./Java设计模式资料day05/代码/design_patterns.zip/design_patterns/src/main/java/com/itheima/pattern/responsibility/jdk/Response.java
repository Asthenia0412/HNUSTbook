package com.itheima.pattern.responsibility.jdk;

/**
 * @version v1.0
 * @ClassName: Response
 * @Description: TODO(一句话描述该类的功能)
 * @Author: 黑马程序员
 */
public interface Response {
}
