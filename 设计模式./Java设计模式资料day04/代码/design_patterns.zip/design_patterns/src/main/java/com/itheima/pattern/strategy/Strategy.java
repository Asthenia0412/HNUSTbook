package com.itheima.pattern.strategy;

/**
 * @version v1.0
 * @ClassName: Strategy
 * @Description: 抽象策略类
 * @Author: 黑马程序员
 */
public interface Strategy {

    void show();
}
