package com.itheima.principles.demo1;

/**
 * @version v1.0
 * @ClassName: DefaultSkin
 * @Description: 默认皮肤类
 * @Author: 黑马程序员
 */
public class DefaultSkin extends AbstractSkin {

    public void display() {
        System.out.println("默认皮肤");
    }
}
