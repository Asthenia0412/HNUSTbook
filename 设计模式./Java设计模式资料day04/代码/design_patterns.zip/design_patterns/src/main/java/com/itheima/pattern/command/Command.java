package com.itheima.pattern.command;

/**
 * @version v1.0
 * @ClassName: Command
 * @Description: 抽象命令类
 * @Author: 黑马程序员
 */
public interface Command {

    void execute();
}
