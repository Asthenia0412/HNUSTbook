package com.itheima.principles.demo4.after;

/**
 * @version v1.0
 * @ClassName: Waterproof
 * @Description: 防水接口
 * @Author: 黑马程序员
 */
public interface Waterproof {
    void waterproof();
}
