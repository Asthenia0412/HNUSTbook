package com.itheima.principles.demo3.after;

/**
 * @version v1.0
 * @ClassName: Cpu
 * @Description: cpu接口
 * @Author: 黑马程序员
 */
public interface Cpu {
    //运行cpu
    public void run();
}
